import java.io.FileReader
import java.io.FileWriter
import java.util.*

var contadorId = 1 // Para gerar IDs únicos

fun main() {
    var brinquedos = mutableListOf<Brinquedo>()

    while (true) {
        menu(brinquedos)
    }
}

fun menu(brinquedos: MutableList<Brinquedo>) {
    println(
        """
        Escolha uma opção:
            1 - Cadastrar
            2 - Exibir a lista
            3 - Gravar csv
            4 - Ler csv
            5 - Fim
        """.trimIndent()
    )
    opcoes(brinquedos)
}

fun opcoes(brinquedos: MutableList<Brinquedo>) {
    println("Selecione uma das opções digitando o número correspondente:")
    val escolhida = readln().toInt()

    when (escolhida) {
        1 -> {
            println("Digite o tipo de brinquedo (Boneca/Lego): ")
            val tipo = readln().lowercase()

            when (tipo) {
                "boneca" -> {
                    println("Digite a altura da boneca em centímetros: ")
                    val altura = readln().toDouble()

                    println("Digite o tipo de cabelo da boneca: ")
                    val tipoCabelo = readln()

                    println("Digite a descrição da boneca: ")
                    val descricao = readln()

                    println("Digite a idade mínima para brincar: ")
                    val idadeMin = readln().toInt()

                    println("Digite o preço: (xx.xx)")
                    val preco = readln().toDouble()

                    println("Digite o material: ")
                    val material = readln()

                    println("Digite a vida útil em anos: ")
                    val vidaUtil = readln().toInt()

                    println("Digite o tipo de brincadeira: ")
                    val tipoBrincadeira = readln()

                    val boneca = Boneca(
                        altura = altura,
                        tipoCabelo = tipoCabelo,
                        codigo = contadorId++,
                        descricao = descricao,
                        idadeMin = idadeMin,
                        preco = preco,
                        material = material,
                        vidaUtil = vidaUtil,
                        tipoBrincadeira = tipoBrincadeira
                    )

                    brinquedos.add(boneca)
                    println("Boneca cadastrada com sucesso!")
                }

                "lego" -> {
                    println("Digite o número de peças do Lego: ")
                    val numPecas = readln().toInt()

                    println("Digite o tema do Lego: ")
                    val tema = readln()

                    println("Digite a descrição do Lego: ")
                    val descricao = readln()

                    println("Digite a idade mínima para brincar: ")
                    val idadeMin = readln().toInt()

                    println("Digite o preço: (xx.xx) ")
                    val preco = readln().toDouble()

                    println("Digite o material: ")
                    val material = readln()

                    println("Digite a vida útil em anos: ")
                    val vidaUtil = readln().toInt()

                    println("Digite o tipo de brincadeira: ")
                    val tipoBrincadeira = readln()

                    val lego = Lego(
                        numPecas = numPecas,
                        tema = tema,
                        codigo = contadorId++,
                        descricao = descricao,
                        idadeMin = idadeMin,
                        preco = preco,
                        material = material,
                        vidaUtil = vidaUtil,
                        tipoBrincadeira = tipoBrincadeira
                    )

                    brinquedos.add(lego)
                    println("Lego cadastrado com sucesso!")
                }

                else -> {
                    println("Tipo de brinquedo inválido.")
                }
            }
        }
        2 -> {
            println("Lista de brinquedos cadastrados:")
            if (brinquedos.isEmpty()) {
                println("Nenhum brinquedo cadastrado.")
            } else {
                brinquedos.forEach { println(it) }
            }
        }
        3 -> {
            if (brinquedos.isEmpty()) {
                println("Não há nada a gravar.")
            } else {
                println("Digite o nome do arquivo CSV para gravar: dica - adicione a extensão csv ")
                val nomeArquivo = readln()
                gravarCsv(brinquedos, nomeArquivo)
            }
        }
        4 -> {
            println("Digite o nome do arquivo CSV para ler: dica - adicione a extensão csv ")
            val nomeArquivo = readln()
            lerCsv(nomeArquivo)
        }
        5 -> {
            println("Encerrando o programa.")
            return
        }
        else -> {
            println("Opção inválida.")
        }
    }
}


fun gravarCsv(brinquedos: List<Brinquedo>, nome: String) {
    val arquivo = FileWriter(nome)
    val saida = Formatter(arquivo)

    // Cabeçalho do CSV
    saida.format("ID;Descrição;Idade Mínima;Preço;Material;Vida Útil;Tipo de Brincadeira;Detalhes Específicos\n")

    for (brinquedo in brinquedos) {
        when (brinquedo) {
            is Boneca -> {
                saida.format(
                    "%d;%s;%d;%.2f;%s;%d;%s;Altura: %.2f, Tipo de cabelo: %s\n",
                    brinquedo.codigo,
                    brinquedo.descricao,
                    brinquedo.idadeMin,
                    brinquedo.preco,
                    brinquedo.material,
                    brinquedo.vidaUtil,
                    brinquedo.tipoBrincadeira,
                    brinquedo.altura,
                    brinquedo.tipoCabelo
                )
            }
            is Lego -> {
                saida.format(
                    "%d;%s;%d;%.2f;%s;%d;%s;Número de peças: %d, Tema: %s\n",
                    brinquedo.codigo,
                    brinquedo.descricao,
                    brinquedo.idadeMin,
                    brinquedo.preco,
                    brinquedo.material,
                    brinquedo.vidaUtil,
                    brinquedo.tipoBrincadeira,
                    brinquedo.numPecas,
                    brinquedo.tema
                )
            }
        }
    }

    saida.close()
    arquivo.close()

    println("Arquivo CSV gravado com sucesso: $nome")
}

fun lerCsv(nome: String) {
    val arquivo = FileReader(nome)
    val leitor = Scanner(arquivo).useDelimiter(";|\\n")

    // Ignorar o cabeçalho
    if (leitor.hasNext()) leitor.nextLine()

    println(String.format("%3S %-20S %10S %7S %-10S %5S %-20S %-30S",
        "ID", "Descrição", "IdadeMin", "Preço", "Material", "Vida", "TipoBrincadeira", "Detalhes"))

    while (leitor.hasNext()) {
        val id = leitor.nextInt()
        val descricao = leitor.next()
        val idadeMin = leitor.nextInt()
        val preco = leitor.nextDouble()
        val material = leitor.next()
        val vidaUtil = leitor.nextInt()
        val tipoBrincadeira = leitor.next()
        val detalhes = leitor.next()

        println(String.format("%03d %-20.20s %-10d %7.2f %-10s %5d %-20s %-30s",
            id, descricao, idadeMin, preco, material, vidaUtil, tipoBrincadeira, detalhes))
    }

    leitor.close()
    arquivo.close()
    println("Leitura do arquivo CSV concluída.")
}

