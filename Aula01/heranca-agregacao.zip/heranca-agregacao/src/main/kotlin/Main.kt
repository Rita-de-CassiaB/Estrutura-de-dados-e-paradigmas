fun main() {
    var testeConsultoria = TesteC()
    testeConsultoria.main()

    var testeProdutora = TesteP()
    testeProdutora.main()
}