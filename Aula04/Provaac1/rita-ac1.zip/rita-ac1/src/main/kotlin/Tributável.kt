interface Tributável {
    fun getImposto():Double
}