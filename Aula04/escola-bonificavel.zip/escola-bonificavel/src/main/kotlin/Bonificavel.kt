interface Bonificavel {
    fun getValorBonus():Double
}