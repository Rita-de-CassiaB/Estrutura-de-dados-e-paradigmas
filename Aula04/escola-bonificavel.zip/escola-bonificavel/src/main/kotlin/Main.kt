fun main() {
    var teste =Teste()
    teste.main()

    }