interface Vendável {
    fun getValorVenda():Double
}