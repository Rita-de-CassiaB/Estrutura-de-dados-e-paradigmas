fun main() {
    var testes = Teste()
    testes.main()
}