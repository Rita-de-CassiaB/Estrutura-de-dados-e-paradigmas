interface Tributavel {
    fun getValorTributo():Double
}