fun main() {
    var testes = TestaTributo()
    testes.main()
}