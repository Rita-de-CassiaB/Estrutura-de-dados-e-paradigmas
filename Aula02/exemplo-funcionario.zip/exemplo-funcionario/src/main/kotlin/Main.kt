fun main() {
    var Teste = Testes()
    Teste.main()
}