fun main(){
    var teste = TestaFigura()
    teste.main()
}